package com.Practica.TecnicaW2M.service;

public interface Inave {

	public String GetNombre(String nom);
}
